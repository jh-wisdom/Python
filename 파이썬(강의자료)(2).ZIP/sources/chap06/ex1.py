import turtle
t = turtle.Turtle()

t.circle(100) 	# 반지름이 100인 원을 그린다. 
t.left(60)    	# 60도 만큼 터틀을 왼쪽으로 회전시킨다. 	
t.circle(100) 
t.left(60)    
t.circle(100) 
t.left(60)    
t.circle(100) 
t.left(60)    
t.circle(100) 
t.left(60)    
t.circle(100) 
