for i in range(5):				# (1)
	print("방문을 환영합니다!")		# (2)
