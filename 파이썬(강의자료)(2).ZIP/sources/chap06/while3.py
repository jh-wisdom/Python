import turtle
t = turtle.Turtle()

i = 0
while i < 4:
	t.forward(100)
	t.right(90)
	i = i + 1
