import turtle
t = turtle.Turtle()
t.shape("turtle")
t.forward(100)
t.left(60)
t.forward(100)
t.left(60)
t.forward(100)
t.left(60)
t.forward(100)
t.left(60)
t.forward(100)
t.left(60)
t.forward(100)

t.circle(100)      	# 반지름이 100인 원이 그려진다. 
