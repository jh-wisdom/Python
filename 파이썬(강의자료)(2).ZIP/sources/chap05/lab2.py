age = int(input("나이를 입력하시오: "))
if age >= 15:
    print("본 영화를 보실 수 있습니다.")
else:
    print("본 영화를 보실 수 없습니다.")
