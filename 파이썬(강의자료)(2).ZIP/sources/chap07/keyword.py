def calc(x, y, z):
    return x+y+z

calc(y=20, x=10, z=30)
