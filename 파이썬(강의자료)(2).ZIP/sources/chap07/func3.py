def calculate_area (radius):
    area = 3.14 * radius**2
    return area
print(calculate_area (5.0))
