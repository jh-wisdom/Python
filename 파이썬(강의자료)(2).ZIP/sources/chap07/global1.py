def calculate_area (radius):
    area = 3.14 * radius**2		# 전역변수 area에 계산값을 저장하려고 했다!
    return

area = 0
r  = float(input("원의 반지름: "))
calculate_area(r)
print(area)
