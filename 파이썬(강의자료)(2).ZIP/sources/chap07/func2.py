def print_address(name):
	print("서울 특별시 종로구 1번지")
	print("파이썬 빌딩 7층")
	print(name)

print_address("홍길동")
