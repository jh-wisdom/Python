phone_book = { }
phone_book["강감찬"] = "010-1234-5679"
print(phone_book["강감찬"])
phone_book.keys()
phone_book.values()

dict = {'Name': '홍길동', 'Age': 7, 'Class': '초급'}
print (dict['Name'])
print (dict['Age'])
