phone_book = { }
phone_book["강감찬"] = "010-1234-5679"
for key in sorted(phone_book.keys()):
    print(key, phone_book[key])
