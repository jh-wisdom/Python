heroes = [ "아이언맨", "토르", "헐크", "스칼렛 위치" ]
del heroes[0] 
print(heroes)
