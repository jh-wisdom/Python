phone_book = { }
phone_book["홍길동"] = "010-1234-5678"
print(phone_book)
phone_book = {"홍길동": "010-1234-5678"}
phone_book["강감찬"] = "010-1234-5679"
phone_book["이순신"] = "010-1234-5680"
print(phone_book)
