heroes = [ "아이언맨", "토르", "헐크", "스칼렛 위치" ]
print(heroes.index("헐크"))
if "헐크" in heroes:
    print(heroes.index("헐크"))
heroes = [ "아이언맨", "토르", "헐크", "스칼렛 위치" ]
for hero in heroes:
	print(hero)
