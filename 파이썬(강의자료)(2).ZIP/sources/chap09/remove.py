heroes = [ "아이언맨", "토르", "헐크", "스칼렛 위치" ]
heroes.remove("스칼렛 위치")
print(heroes)
