heroes = [ "아이언맨", "토르", "헐크", "스칼렛 위치" ]
heroes[1] = "닥터 스트레인지"
print(heroes)
heroes.append("스파이더맨")
print(heroes)
heroes.insert(1, "배트맨")
print(heroes)
