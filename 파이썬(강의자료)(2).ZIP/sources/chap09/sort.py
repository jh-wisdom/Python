heroes = [ "아이언맨", "토르", "헐크", "스칼렛 위치" ]
heroes.sort()
print(heroes)

numbers = [ 9, 6, 7, 1, 8, 4, 5, 3, 2 ]
numbers.sort()
print(numbers)
