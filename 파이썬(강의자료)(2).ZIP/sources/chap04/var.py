x = 10
print("x =", x)

x = 3.14
print("x =", x)

x = "Hello World!"
print("x =", x)
