t = input("정수를 입력하시오: ")
x = int(t)

t = input("정수를 입력하시오: ")
y = int(t)

print(x+y)
