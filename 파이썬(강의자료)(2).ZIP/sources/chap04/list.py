slist = [ '영어', '수학', '사회', '과학' ]


list1 = [ 1, 2, 3, 4, 5 ]
list2 = [ "a", "b", "c", "d" ]


list = []
list.append(1)
list.append(2)
list.append(6)
list.append(3)

print(list)
