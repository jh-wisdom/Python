year = input("오늘의 연도를 입력하시오: ")
month = input("오늘의 월을 입력하시오: ")
date = input("오늘의 일을 입력하시오: ")

print("오늘은", year+"년", month+"월", date+"일입니다.")
