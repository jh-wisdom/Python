friend_list = [ ]

friend = input("친구의 이름을 입력하시오: ")
friend_list.append(friend)

friend = input("친구의 이름을 입력하시오: ")
friend_list.append(friend)

friend = input("친구의 이름을 입력하시오: ")
friend_list.append(friend)

friend = input("친구의 이름을 입력하시오: ")
friend_list.append(friend)

friend = input("친구의 이름을 입력하시오: ")
friend_list.append(friend)

print(friend_list)
