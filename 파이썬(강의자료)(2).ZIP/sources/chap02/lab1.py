import turtle
t = turtle.Turtle()
t.shape("turtle")
radius = 50
t.circle(radius)      	# 반지름이 100인 원이 그려진다. 
t.fd(30)
t.circle(radius)      	# 반지름이 100인 원이 그려진다. 
t.fd(30)
t.circle(radius)      	# 반지름이 100인 원이 그려진다. 
