street = "서울시 종로구"
type = "아파트"
number_of_rooms = 3
price = 100000000

print("###############################")
print("#                             #")
print("#     부동산 매물 광고          #")
print("#                             #")
print("###############################")
print("")
print(street, "에 위치한 아주 좋은 ", type, "가 매물로 나왔습니다. 이 ",
	type, "는 ", number_of_rooms, "개의 방을 가지고 있으며 가격은",
      price, "입니다.")
