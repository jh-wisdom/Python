from tkinter import *

window = Tk()
button = Button(window, text="클릭하세요!")
button.pack()

window.mainloop()
