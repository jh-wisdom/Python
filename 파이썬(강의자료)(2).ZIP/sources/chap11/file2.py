infile = open("phones.txt", "r")
lines = infile.readlines() 
print(lines)
