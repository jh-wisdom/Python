sec = 1000
min = 1000 // 60
remainder = 1000 % 60
print(min, remainder)
