ftemp = int(input("화씨온도: "))
ctemp = (ftemp-32.0)*5.0/9.0
print("섭씨온도:", ctemp)

