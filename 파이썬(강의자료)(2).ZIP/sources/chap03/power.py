a=1000
r=0.05
n=10
print(a*(1+r)**n)
