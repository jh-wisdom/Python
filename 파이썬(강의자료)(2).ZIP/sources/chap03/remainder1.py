p = int(input("분자를 입력하시오: "))
q = int(input("분모를 입력하시오: "))
print("나눗셈의 몫=", p // q)
print("나눗셈의 나머지=", p % q)
